from frappe import _


def get_data():
    return [
        {
            "module_name": "Media Advertising",
            "app": "media_advertising",
            "label": _("Media Advertising"),
            "color": "#e74c3c",
            "icon": "uil uil-chart",
            "type": "module",
            "description": _("Media & Advertising Campaign Management"),
        }
    ]
