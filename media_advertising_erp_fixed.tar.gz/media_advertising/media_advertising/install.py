import frappe
import os
import json


def after_install():
    """Called by bench after app install — force-create the workspace record."""
    create_workspace()
    create_default_fixtures()


def create_workspace():
    if frappe.db.exists("Workspace", "Media Advertising"):
        return

    ws_path = os.path.join(
        os.path.dirname(__file__), "workspace", "media_advertising.json"
    )
    if not os.path.exists(ws_path):
        frappe.log_error("media_advertising workspace JSON not found", "Install")
        return

    with open(ws_path) as f:
        ws_data = json.load(f)

    # Remove fields that cause issues on direct insert
    ws_data.pop("creation", None)
    ws_data.pop("modified", None)
    ws_data.pop("modified_by", None)
    ws_data.pop("owner", None)

    doc = frappe.get_doc(ws_data)
    doc.insert(ignore_permissions=True)
    frappe.db.commit()
    frappe.msgprint("Media Advertising workspace created.", indicator="green")


def create_default_fixtures():
    """Insert default master records if they don't exist."""
    _insert_if_missing("Industry Vertical", [
        {"vertical_name": "FMCG"}, {"vertical_name": "Automobile"},
        {"vertical_name": "Technology"}, {"vertical_name": "BFSI"},
        {"vertical_name": "E-Commerce"}, {"vertical_name": "Real Estate"},
        {"vertical_name": "Healthcare"}, {"vertical_name": "Education"},
        {"vertical_name": "Retail"},
    ])
    _insert_if_missing("Media Category", [
        {"category_name": "Television", "category_type": "Broadcast"},
        {"category_name": "Radio", "category_type": "Radio"},
        {"category_name": "Print - Newspaper", "category_type": "Print"},
        {"category_name": "Digital - Display", "category_type": "Digital"},
        {"category_name": "Digital - Social", "category_type": "Digital"},
        {"category_name": "OOH - Hoarding", "category_type": "OOH"},
        {"category_name": "Cinema", "category_type": "Cinema"},
    ])
    _insert_if_missing("Ad Format", [
        {"format_name": "30s TVC", "duration_seconds": 30},
        {"format_name": "60s TVC", "duration_seconds": 60},
        {"format_name": "15s Digital Video", "duration_seconds": 15},
        {"format_name": "Leaderboard Banner", "dimensions": "728x90"},
        {"format_name": "Rectangle Banner", "dimensions": "300x250"},
        {"format_name": "Social Post - Static"},
        {"format_name": "OOH 40x20 ft"},
    ])
    _insert_if_missing("KPI Definition", [
        {"kpi_name": "GRP", "kpi_code": "GRP", "kpi_type": "Reach", "unit": "GRPs"},
        {"kpi_name": "CPM", "kpi_code": "CPM", "kpi_type": "Cost", "unit": "INR/1000"},
        {"kpi_name": "CTR", "kpi_code": "CTR", "kpi_type": "Engagement", "unit": "%"},
        {"kpi_name": "Reach", "kpi_code": "REACH", "kpi_type": "Reach", "unit": "Persons"},
        {"kpi_name": "ROAS", "kpi_code": "ROAS", "kpi_type": "ROI", "unit": "x"},
    ])


def _insert_if_missing(doctype, records):
    for r in records:
        name_field = list(r.keys())[0]
        if not frappe.db.exists(doctype, r[name_field]):
            doc = frappe.get_doc({"doctype": doctype, **r})
            try:
                doc.insert(ignore_permissions=True)
            except Exception as e:
                frappe.log_error(str(e), f"Install {doctype}")
    frappe.db.commit()
