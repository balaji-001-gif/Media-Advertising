import frappe


def boot_session(bootinfo):
    """Ensure Media Advertising workspace appears for all users."""
    pass
